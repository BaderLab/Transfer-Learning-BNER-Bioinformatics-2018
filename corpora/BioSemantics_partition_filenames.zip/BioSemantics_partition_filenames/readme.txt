This directory contain three files. Each file contains the filenames placed in the train/valid/test partitions of the split corpus, respectively. 

The full corpus was obtained from: https://biosemantics.org/index.php/resources/chemical-patent-corpus. Note that we used the "full set".